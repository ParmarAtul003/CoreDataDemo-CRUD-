//
//  ViewController.swift
//  CodeDataDemo
//
//  Created by Atul Parmar on 08/04/19.
//  Copyright © 2019 Atul Parmar. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(urls[urls.count-1] as URL)
        
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        let context = appDelegate.persistentContainer.viewContext
        
        //Add new record to the database....
        
//        let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)
//        let newUser = NSManagedObject(entity: entity!, insertInto: context)
//        newUser.setValue("atul123", forKey: "username")
//        newUser.setValue("1234445", forKey: "password")
//        newUser.setValue("25", forKey: "age")
//
//        do {
//            try context.save()
//        } catch {
//            print("Failed saving")
//        }
        
        
        //Get data from coredata....
        
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
//        //request.predicate = NSPredicate(format: "age = %@", "12")
//        request.returnsObjectsAsFaults = false
//        do {
//            let result = try context.fetch(request)
//            for data in result as! [NSManagedObject] {
//                print(data.value(forKey: "username") as! String)
//            }
//
//        } catch {
//
//            print("Failed")
//        }
        
        
        //Edit record....
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
//        request.predicate = NSPredicate(format: "age = %@", "25")
//        request.returnsObjectsAsFaults = false
//        do {
//            let result = try context.fetch(request)
//
//            let objectupdate = result[0] as! NSManagedObject
//
//            objectupdate.setValue("atul456", forKey: "username")
//            objectupdate.setValue("123", forKey: "password")
//            objectupdate.setValue("30", forKey: "age")
//
//            do {
//                try context.save()
//            } catch {
//                print("Failed saving")
//            }
//
//        } catch {
//            
//            print("Failed")
//        }
        
        //Delete record...
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
//        request.predicate = NSPredicate(format: "age = %@", "30")
//        request.returnsObjectsAsFaults = false
//        do {
//            let result = try context.fetch(request)
//
//            let objectDelete = result[0] as! NSManagedObject
//           context.delete(objectDelete)
//
//            do {
//                try context.save()
//            } catch {
//                print("Failed saving")
//            }
//
//        } catch {
//
//            print("Failed")
//        }

        
    }


}

